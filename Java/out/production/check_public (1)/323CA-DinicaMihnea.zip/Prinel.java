import java.io.*;
import java.util.*;

import static java.lang.Math.max;
import static java.lang.Math.sqrt;

public class Prinel {
    public Integer N;
    public Integer K;
    public Integer maxi = 0;
    public ArrayList<Integer> targets = new ArrayList<>();
    public ArrayList<Integer> points = new ArrayList<>();
    public ArrayList<Integer> transformations = new ArrayList<>();
    public void read() throws FileNotFoundException {
        File input = new File("prinel.in");
        Scanner scanner = new Scanner(input);
        this.N = scanner.nextInt();
        this.K = scanner.nextInt();

        // read the target values vector and get its maximum
        for (int i = 0; i < this.N; i++) {
            int toAdd = scanner.nextInt();
            this.targets.add(toAdd);
            if (toAdd > this.maxi) {
                this.maxi = toAdd;
            }
        }

        // read the points values vector
        for (int i = 0; i < this.N; i++) {
            this.points.add(scanner.nextInt());
        }

        scanner.close();
    }

    // Function that returns a vector of a number's divisors
    public ArrayList<Integer> get_divisors(int x) {
        ArrayList<Integer> divs = new ArrayList<>();
        divs.add(1);
        if (x == 1)
            return divs;

        for (int i = 2; i <= sqrt(x); i++) {
            if (x % i == 0) {
                divs.add(i);
                divs.add(x / i);
            }
        }
        divs.add(x);
        return divs;
    }

    // Compute using DP the minimum number of steps it takes to reach a certain
    // value; initially consider you need n - 1 steps to reach n and check if you
    // can reach it faster by adding a divisor to a certain value before it
    public void precompute() {
        // don't take position 0 into consideration
        this.transformations.add(0);
        for (int i = 0; i < this.maxi; i++) {
            this.transformations.add(i);
        }
        for (int i = 1; i < transformations.size(); i++) {
            ArrayList<Integer> divs = get_divisors(i);
            for (int div : divs) {
                if (i + div < this.transformations.size() && this.transformations.get(i + div) > 1 + this.transformations.get(i)) {
                    this.transformations.set(i + div, 1 + this.transformations.get(i));
                }
            }
        }
    }
    // Function that solves the task using dynamic programing and writes the answer in file
    public void solve() throws IOException {
//        int[][] dp = new int[this.N + 1][this.K + 1];
//        int[] dp_curr = new int[this.K + 1];
//        int[] dp_prev = new int[this.K + 1];
        ArrayList<Integer> dp_curr = new ArrayList<>();
        ArrayList<Integer> dp_prev = new ArrayList<>();

        // so i - 1 in the table will not be out of bounds
        for (int i = 0; i < this.K + 1; i++) {
            dp_prev.add(0);
        }

        for (int i = 1; i < this.N + 1; i++) {
            for (int j = 0; j < this.K + 1; j++) {
                // can't use this number as it involves to many steps to convert it
                if (j < this.transformations.get(this.targets.get(i - 1))) {
                    // keep the previous result if exists
//                    dp[i][j] = dp[i - 1][j];
                    dp_curr.add(dp_prev.get(j));
                } else {
                    // I have enough steps to convert this number, but check if it's worth it
//                    dp[i][j] = max(dp[i - 1][j], this.points.get(i - 1) + dp[i - 1][j - this.transformations.get(this.targets.get(i - 1))]);
                    dp_curr.add(max(dp_prev.get(j), this.points.get(i - 1) + dp_prev.get(j - this.transformations.get(this.targets.get(i - 1)))));
                }
            }
            dp_prev = new ArrayList<>(dp_curr);
            dp_curr.clear();
        }

        PrintWriter printWriter = new PrintWriter(new FileWriter("prinel.out"));
//        printWriter.println(dp[this.N][this.K]);
        printWriter.println(dp_prev.get(this.K));
        printWriter.close();
    }

    public static void main(String[] args) throws IOException {
        Prinel pb = new Prinel();
        pb.read();
        pb.precompute();
        pb.solve();
    }
}