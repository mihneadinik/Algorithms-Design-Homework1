import java.io.*;
import java.util.*;

public class Crypto {
    public Integer N;
    public Integer L;
    public String K;
    public String S;
    public ArrayList<String> words = new ArrayList<>();
    public Queue<StringBuilder> qords= new LinkedList<>();

    public  void read() throws FileNotFoundException {
        File input = new File("crypto.in");
        Scanner scanner = new Scanner(input);
        this.N = scanner.nextInt();
        this.L = scanner.nextInt();
        this.K = scanner.next();
        this.S = scanner.next();

        scanner.close();
    }

    public void generateWords() {
        this.words.add("");
        int nrQ = 0;
        LinkedHashSet<Character> chars = new LinkedHashSet<>();
        for (int i = 0; i < this.L; i++) {
            chars.add(this.S.charAt(i));
        }

        StringBuilder word = new StringBuilder();
        for (int i = 0; i < this.N; i++) {
            if (this.K.charAt(i) != '?') {
                word.append(this.K.charAt(i));
            } else {
                nrQ++;
                qords.add(word);
                word = new StringBuilder();
            }
        }
        qords.add(word);

        if (nrQ == 0) {
            this.words.set(0, word.toString());
            return;
        }

        nrQ = 1;
        while(this.qords.size() > 1) {
            StringBuilder part = this.qords.poll();
            ArrayList<String> partAndChars = new ArrayList<>();
            for (Character ch : chars) {
                partAndChars.add(part.toString() + ch);
            }

            for (int i = 0; i < nrQ; i++) {
                String copy = this.words.get(0);
                this.words.remove(0);
                for (int j = 0; j < partAndChars.size(); j++) {
                    this.words.add(copy + partAndChars.get(j));
                }
            }

            nrQ *= 2;
        }

//        for (int i = 0; i < this.words.size(); i++) {
//            this.words.set(i, this.words.get(i) + this.qords.peek().toString());
//            System.out.println(this.words.get(i));
//        }
    }

    public int findNumberOccurences(String big, String small) {
        int [][] dp = new int[big.length() + 1][small.length() + 1];
        for (int i = 0; i < big.length() + 1; i++) {
            for (int j = 0; j < small.length() + 1; j++) {
                dp[i][j] = -1;
            }
        }

        return rec(big, small, dp) % 1000000007;
    }

    public int rec(String big, String small, int[][] dp) {
        if (small.length() == 0) {
            return 1;
        }

        if (big.length() == 0) {
            return 0;
        }

        if (dp[big.length()][small.length()] != -1) {
            return dp[big.length()][small.length()];
        }

        dp[big.length()][small.length()] = rec(big.substring(0, big.length() - 1), small, dp);

        if (big.charAt(big.length() - 1) == small.charAt(small.length() - 1)) {
            dp[big.length()][small.length()] += rec(big.substring(0, big.length() - 1), small.substring(0, small.length() - 1), dp);
        }

        return dp[big.length()][small.length()];
    }

    public void solve() throws IOException {
        int total = 0;
        for (int i = 0; i < this.words.size(); i++) {
            total += findNumberOccurences(this.words.get(i), this.S);
            total %= 1000000007;
        }

        PrintWriter printWriter = new PrintWriter(new FileWriter("crypto.out"));
        printWriter.println(total);
        printWriter.close();
    }

    public static void main(String[] args) throws IOException {
        Crypto pb = new Crypto();
        pb.read();
        pb.generateWords();
        pb.solve();
    }
}
