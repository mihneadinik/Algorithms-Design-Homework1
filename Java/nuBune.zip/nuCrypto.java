import java.io.*;
import java.util.*;

public class Crypto {
	public Integer N;
	public Integer L;
	public String K;
	public String S;
	public long[][] dp;
	public ArrayList<String> words = new ArrayList<>();
	public Queue<StringBuilder> qords= new LinkedList<>();

	public  void read() throws FileNotFoundException {
		File input = new File("crypto.in");
		Scanner scanner = new Scanner(input);
		this.N = scanner.nextInt();
		this.L = scanner.nextInt();
		this.K = scanner.next();
		this.S = scanner.next();

		this.dp = new long[this.N + 1][this.L + 1];

		scanner.close();
	}

	public void solve() throws IOException {
		LinkedHashSet<Character> chars = new LinkedHashSet<>();
		for (int i = 0; i < this.L; i++) {
			chars.add(this.S.charAt(i));
		}
		long uniqueChars = chars.size();

		long branches = 1;

		// if the key has no characters
		for (int i = 0; i <= this.L; i++) {
			dp[0][i] = 0;
		}

		// if the substring has no remaining characters,
		// then it's one occurrence per branch
		dp[0][0] = 1;
		for (int i = 1; i <= this.N; i++) {
			if (this.K.charAt(i - 1) == '?') {
				branches *= uniqueChars;
			}
			dp[i][0] = branches;
		}

		for (int i = 1; i <= this.N; i++) {
			char currChar = this.K.charAt(i - 1);
			for (int j = 1; j <= this.L; j++) {
				if (currChar == this.S.charAt(j - 1)) {
					// found matching characters
					dp[i][j] = ((dp[i - 1][j - 1] + dp[i - 1][j]) % 1000000007);
				} else {
					// characters don't match, check for '?'
					if (currChar == '?') {
						dp[i][j] = ((((long)(uniqueChars * dp[i - 1][j]) % 1000000007) + dp[i - 1][j - 1]) % 1000000007);
					} else {
						dp[i][j] = dp[i - 1][j];
					}
				}
			}
		}

		for (int i = 0; i <= this.N; i++) {
			for (int j = 0; j <= this.L; j++) {
				System.out.printf(dp[i][j] + " ");
			}
			System.out.println();
		}

		PrintWriter printWriter = new PrintWriter(new FileWriter("crypto.out"));
		printWriter.println(dp[this.N][this.L]);
		printWriter.close();
	}

	public static void main(String[] args) throws IOException {
		Crypto pb = new Crypto();
		pb.read();
		pb.solve();
	}
}
