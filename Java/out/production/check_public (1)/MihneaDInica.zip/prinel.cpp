#include <fstream>
#include <iostream>
#include <bits/stdc++.h>

#define file_in "prinel.in"
#define file_out "prinel.out"

int s = 1;

// Function that reads the input file
void read(int &n, int &k, std::vector<int> &targets, std::vector<int> &points, int &maxi) {
    std::ifstream in;
    in.open(file_in);
    in >> n >> k;

    // read the target values vector
    for (int i = 0; i < n; i++) {
        int x;
        in >> x;
        if (x > maxi) {
            maxi = x;
        }
        targets.push_back(x);
    }

    // read the points values vector
    for (int i = 0; i < n; i++) {
        int x;
        in >> x;
        points.push_back(x);
    }

    in.close();
}

// Function that returns a vector of a number's divizors
std::vector<int> get_divizors(int x, std::unordered_map<int, std::vector<int>> &mem) {
    std::vector<int> out(1, 1);
    if (x == 1) {
        return out;
    }

    if (mem.find(x) != mem.end()) {
        std::vector<int> vec = mem[x];
        vec.push_back(x);
        mem[x * 2] = vec;
        return vec;
    }

    for (int i = sqrt(x); i >= 2; i--) {
        if (x % i == 0) {
            out.push_back(i);
            out.push_back(x / i);
        }
    }

    out.push_back(x);
    if (x == 1 << s) {
        mem[x * 2] = out;
        s++;
    }
    return out;
}

void precompute(std::vector<int> &transformations, std::unordered_map<int, std::vector<int>> &mem) {
    for (int i = 2; i < transformations.size(); i++) {
        std::vector<int> divs = get_divizors(i, mem);
        for (int div : divs) {
            int res = i + div;
            int futureSteps = 1 + transformations[i];
            if (res < transformations.size() && transformations[res] > futureSteps) {
                transformations[res] = futureSteps;
            }
        }
    }
}

// Function that solves the task using dynamic programing and writes the answer in file
void solve(int n, int k, std::vector<int> &points, std::vector<int> &targets, std::vector<int> &transformations) {
    std::ofstream out;
    out.open(file_out);

    // Check if we can manage all the transformations without computing the DP
    int sum = 0;
    int res = 0;
    for (int i = 0; i < n; i++) {
        sum += transformations[targets[i]];
        res += points[i];
    }
    if (sum < k) {
        out << res << std::endl;
        return;
    }

    std::vector<int> dp_curr(k + 1, 0);
    std::vector<int> dp_prev(k + 1, 0);

    for (int i = 0; i < n; i++) {
        int target = targets[i];
        int necessarySteps = transformations[target];
        int point = points[i];
        for (int j = 0; j < k + 1; j++) {
            // can't use this number as it involves to many steps to convert it
            if (j < necessarySteps) {
                // keep the previous result if exists
                dp_curr[j] = dp_prev[j];
            } else {
                // I have enough steps to convert this number, but check if it's worth it
                dp_curr[j] = std::max(dp_prev[j], point + dp_prev[j - necessarySteps]);
            }
        }
        dp_prev = dp_curr;
    }
    out << dp_curr[k] << std::endl;

    out.close();
}

int main() {
    int n, k, maxi = -1;
    std::vector<int> targets;
    std::vector<int> points;
    read(n, k, targets, points, maxi);
    std::vector<int> transformations(maxi + 1);
    std::iota(transformations.begin() + 1, transformations.end(), 0);
    std::unordered_map<int, std::vector<int>> mem;
    precompute(transformations, mem);
    solve(n, k, points, targets, transformations);
    return 0;
}