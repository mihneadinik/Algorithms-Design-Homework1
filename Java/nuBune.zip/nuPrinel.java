import java.io.*;
import java.util.*;

import static java.lang.Math.*;

public class nuPrinel {
	public Integer N;
	public Integer K;
	public Integer maxi = 0;
	public int[] targets;
//	public ArrayList<Integer> targets = new ArrayList<>();
	public int[] points;
//	public ArrayList<Integer> points = new ArrayList<>();
	public int[] transformations;
	public void read() throws FileNotFoundException {
		File input = new File("prinel.in");
		Scanner scanner = new Scanner(input);
		this.N = scanner.nextInt();
		this.K = scanner.nextInt();
		this.targets = new int[this.N];
		this.points = new int[this.N];

		// read the target values vector and get its maximum
		for (int i = 0; i < this.N; i++) {
			int toAdd = scanner.nextInt();
			this.targets[i] = toAdd;
			if (toAdd > this.maxi) {
				this.maxi = toAdd;
			}
		}

		// read the points values vector
		for (int i = 0; i < this.N; i++) {
			this.points[i] = scanner.nextInt();
		}

		scanner.close();
	}

	// Function that returns a vector of a number's divisors
	public ArrayList<Integer> get_divisors(int x) {
		ArrayList<Integer> divs = new ArrayList<>();
		divs.add(1);
		if (x == 1)
			return divs;

		for (int i = (int) sqrt(x); i >= 2; i--) {
			if (x % i == 0) {
				divs.add(i);
				divs.add(x / i);
			}
		}
		divs.add(x);
		return divs;
	}

	// Compute using DP the minimum number of steps it takes to reach a certain
	// value; initially consider you need n - 1 steps to reach n and check if you
	// can reach it faster by adding a divisor to a certain value before it
	public void precompute() {
		// don't take position 0 into consideration
		this.transformations = new int[this.maxi + 1];
		for (int i = 1; i <= this.maxi; i++) {
			this.transformations[i] = i - 1;
		}
		for (int i = 2; i < this.maxi; i++) {
			ArrayList<Integer> divs = get_divisors(i);
			int futureSteps = this.transformations[i] + 1;
			for (int div : divs) {
				int c = i + div;
				if (c <= this.maxi && this.transformations[c] > futureSteps) {
					this.transformations[c] = futureSteps;
				}
			}
		}
	}
	// Function that solves the task using dynamic programing and writes the answer in file
	public void solve() throws IOException {
		int[][] dp = new int[this.N + 1][this.K + 1];

		// so i - 1 in the table will not be out of bounds
		for (int i = 0; i <= this.K; i++) {
			dp[0][i] = 0;
		}

		for (int i = 1; i <= this.N; i++) {
			int idx = i - 1;
			int target = this.targets[idx];
			int point = this.points[idx];
			int necessarySteps = this.transformations[target];
			for (int j = 0; j < this.K + 1; j++) {
				// can't use this number as it involves to many steps to convert it
				if (j < necessarySteps) {
					// keep the previous result if exists
					dp[i][j] = dp[idx][j];
				} else {
					// I have enough steps to convert this number, but check if it's worth it
					dp[i][j] = max(dp[idx][j], point + dp[idx][j - necessarySteps]);
				}
			}
		}

		PrintWriter printWriter = new PrintWriter(new FileWriter("prinel.out"));
		printWriter.println(dp[this.N][this.K]);
		printWriter.close();
	}

	public static void main(String[] args) throws IOException {
		nuPrinel pb = new nuPrinel();
		pb.read();
		pb.precompute();
		pb.solve();
	}
}